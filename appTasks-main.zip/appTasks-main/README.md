# appTasks

Desarrollado en Android Studio con JAVA


## Integrantes

* Mario Josué Beltrán García BG171969
* Andrés Eduardo Molina Moz MM161405

## Documentación

En la carpeta llamadas "documents"
