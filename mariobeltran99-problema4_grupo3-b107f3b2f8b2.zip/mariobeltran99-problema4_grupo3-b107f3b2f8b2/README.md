# README #

Problema 4 - Grupo #3

# Integrantes #

* Patricia Guadalupe Quintanilla Rodríguez - QR140595
* Haydee Margarita Melgar Vasquez - MV140138
* Manuel Alejandro Hurtado Pineda - HP150470
* Gerardo Alexander Rivera Moreno - RM170126
* Mario Josué Beltrán García - BG171969
* Andrés Eduardo Molina Moz - MM161405

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact